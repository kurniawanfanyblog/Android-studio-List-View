package com.uty.listviewpresiden

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.uty.listviewpresiden.adapter.listfotopresiden
import com.uty.listviewpresiden.model.fotopresiden
import com.uty.listviewpresiden.model.datafotopresiden

class MainActivity : AppCompatActivity() {
    private lateinit var  rvfotopresiden: RecyclerView
    private var list: ArrayList<fotopresiden> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvfotopresiden = findViewById(R.id.rv_fotopresiden)
        rvfotopresiden.setHasFixedSize(true)
        list.addAll(datafotopresiden.listfotopresiden)
        showfotopresidenList()
    }

    private fun showfotopresidenList(){
        rvfotopresiden.layoutManager = LinearLayoutManager(this)
        rvfotopresiden.adapter = listfotopresiden(this,list){
            Toast.makeText(this,it.detail,Toast.LENGTH_SHORT).show();
        }
    }
}
