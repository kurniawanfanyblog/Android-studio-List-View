package com.uty.listviewpresiden.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.uty.listviewpresiden.R
import com.uty.listviewpresiden.model.fotopresiden
import com.uty.listviewpresiden.model.datafotopresiden.listfotopresiden

class listfotopresiden (private val context: Context, private val fotopresiden: ArrayList<fotopresiden>, private val listener: (fotopresiden) -> Unit)
    : RecyclerView.Adapter<listfotopresiden.ViewHolder>(){


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): listfotopresiden.ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.listfotopresiden_item, parent, false))

    }

    override fun getItemCount(): Int {
        return listfotopresiden.size
    }

    override fun onBindViewHolder(holder: listfotopresiden.ViewHolder, position: Int) {
        holder.bindfotopresiden(fotopresiden[position], listener)

    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvName: TextView = view.findViewById(R.id.tv_item_name)
        var tvDetail: TextView = view.findViewById(R.id.tv_item_detail)
        var imgPoster: ImageView = view.findViewById(R.id.img_item_poster)

        fun bindfotopresiden(fotopresiden: fotopresiden, listener: (fotopresiden) -> Unit){
            tvName.text = fotopresiden.name
            tvDetail.text = fotopresiden.detail
            Glide.with(itemView.context)
                .load(fotopresiden.poster)
                .into(imgPoster)

            
        }
    }
}