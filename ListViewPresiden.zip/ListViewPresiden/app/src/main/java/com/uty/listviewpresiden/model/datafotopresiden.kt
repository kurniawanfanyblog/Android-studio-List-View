package com.uty.listviewpresiden.model

import com.uty.listviewpresiden.R
import com.uty.listviewpresiden.model.fotopresiden as fotopresiden

object datafotopresiden {
    private val nama_fotopresiden = arrayOf(
        "Presiden Soekarno",
        "Presiden Soeharto",
        "Presiden BJ Habieie",
        "Presiden Abdurahman Wahid",
        "Presiden Megawati Soekarno Putri",
        "Presiden Susuilo Bambang Yudhoyono",
        "Presiden Joko Widodo"

    )

    private val detail = arrayOf(
        "Presiden Dr. Ir. H. Soekarno adalah Presiden pertama Republik Indonesia yang menjabat pada periode 1945–1967",
        "Presiden Jenderal Besar TNI H. M. Soeharto, adalah Presiden kedua Indonesia yang menjabat dari tahun 1967 sampai 1998",
        "Presiden Prof. Dr. Ing. H. Bacharuddin Jusuf Habibie, FREng adalah Presiden Republik Indonesia yang ketiga",
        "Presiden Dr. K. H. Abdurrahman Wahid atau yang akrab disapa Gus Dur adalah tokoh Muslim Indonesia dan pemimpin politik yang menjadi Presiden Indonesia yang keempat dari tahun 1999 hingga 2001",
        "Presiden Dr. Hj. Dyah Permata Megawati Setyawati Soekarnoputri Presiden Indonesia yang kelima yang menjabat sejak 23 Juli 2001 sampai 20 Oktober 2004",
        "Presiden Jenderal TNI Prof. Dr. H. Susilo Bambang Yudhoyono, M.A., GCB., AC. adalah Presiden Indonesia ke-6 yang menjabat sejak 20 Oktober 2004 hingga 20 Oktober 2014",
        "Presiden Ir. H. Joko Widodo atau Jokowi adalah Presiden ke-7 Indonesia yang mulai menjabat sejak 20 Oktober 2014. Ia terpilih bersama Wakil Presiden Muhammad Jusuf Kalla dalam Pemilu Presiden 2014"


    )

    private val fotopresidenPoster = intArrayOf(
        R.drawable.sukarno,
        R.drawable.suhart,
        R.drawable.habib,
        R.drawable.gus,
        R.drawable.mega,
        R.drawable.susilo,
        R.drawable.joko


    )

    val listfotopresiden: ArrayList<fotopresiden>
        get(){
            val list = arrayListOf<fotopresiden>()
            for (position in nama_fotopresiden.indices){
                val fotopresiden = fotopresiden()
                fotopresiden.name = nama_fotopresiden[position]
                fotopresiden.detail = detail[position]
                fotopresiden.poster = fotopresidenPoster[position]
                list.add(fotopresiden)
            }
            return list
        }
}