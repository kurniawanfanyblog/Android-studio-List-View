package com.uty.listviewpresiden.model

class fotopresiden {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}