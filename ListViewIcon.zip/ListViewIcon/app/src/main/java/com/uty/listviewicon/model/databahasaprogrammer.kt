package com.uty.listviewicon.model

import com.uty.listviewicon.R
import com.uty.listviewicon.model.bahasaprogrammer as bahasaprogrammer

object databahasaprogrammer {
    private val nama_bahasaprogrammer = arrayOf(
        "Ruby",
        "Ralis",
        "Phyton",
        "Java Script",
        "PHP"
    )

    private val detail = arrayOf(
        "Ruby is an open-source and fully object-oriented programming language",
        "Ruby on Ralis is a server-side web application development framework written in Ruby language",
        "Phyton is interpreted scripting and object-oriented programming language",
        "Java Script is an object-based scripting language",
        "PHP is an interpreted language, i.e., there is no need for compilation"
    )

    private val bahasaprogrammerPoster = intArrayOf(
        R.drawable.ruby,
        R.drawable.ralis,
        R.drawable.phyton,
        R.drawable.javascript,
        R.drawable.php
    )

    val listbahasaprogrammer: ArrayList<com.uty.listviewicon.model.bahasaprogrammer>
        get(){
            val list = arrayListOf<com.uty.listviewicon.model.bahasaprogrammer>()
            for (position in nama_bahasaprogrammer.indices){
                val bahasaprogrammer = com.uty.listviewicon.model.bahasaprogrammer()
                bahasaprogrammer.name = nama_bahasaprogrammer[position]
                bahasaprogrammer.detail = detail[position]
                bahasaprogrammer.poster = bahasaprogrammerPoster[position]
                list.add(bahasaprogrammer)
            }
            return list
        }
}