package com.uty.listviewicon

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.uty.listviewicon.adapter.listbahasaprogrammer
import com.uty.listviewicon.model.bahasaprogrammer
import com.uty.listviewicon.model.databahasaprogrammer

class MainActivity : AppCompatActivity() {
    private lateinit var rvbahasaprogrammer: RecyclerView
    private var list: ArrayList<bahasaprogrammer> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvbahasaprogrammer = findViewById(R.id.rv_bahasaprogrammer)
        rvbahasaprogrammer.setHasFixedSize(true)
        list.addAll(databahasaprogrammer.listbahasaprogrammer)
        showbahasaprogrammerList()
    }

    private fun showbahasaprogrammerList(){
        rvbahasaprogrammer.layoutManager = LinearLayoutManager(this)
        rvbahasaprogrammer.adapter = listbahasaprogrammer(this,list){
            Toast.makeText(this,it.detail,Toast.LENGTH_SHORT).show();
        }
    }
}
