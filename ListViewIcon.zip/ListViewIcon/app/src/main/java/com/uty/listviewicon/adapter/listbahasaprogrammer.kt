package com.uty.listviewicon.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.uty.listviewicon.R
import com.uty.listviewicon.model.bahasaprogrammer
import com.uty.listviewicon.model.databahasaprogrammer.listbahasaprogrammer

class listbahasaprogrammer (private val context: Context, private val bahasaprogrammer: ArrayList<bahasaprogrammer>, private val listener: (bahasaprogrammer) -> Unit)
    : RecyclerView.Adapter<listbahasaprogrammer.ViewHolder>(){


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): listbahasaprogrammer.ViewHolder {
        return ViewHolder(LayoutInflater.from(context).inflate(R.layout.bahasaprogrammer_item, parent, false))

    }

    override fun getItemCount(): Int {
        return listbahasaprogrammer.size
    }

    override fun onBindViewHolder(holder: listbahasaprogrammer.ViewHolder, position: Int) {
        holder.bindbahasaprogrammer(bahasaprogrammer[position], listener)

    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var tvName: TextView = view.findViewById(R.id.tv_item_name)
        var tvDetail: TextView = view.findViewById(R.id.tv_item_detail)
        var imgPoster: ImageView = view.findViewById(R.id.img_item_poster)

        fun bindbahasaprogrammer(bahasaprogrammer: bahasaprogrammer, listener: (bahasaprogrammer) -> Unit){
            tvName.text = bahasaprogrammer.name
            tvDetail.text = bahasaprogrammer.detail
            Glide.with(itemView.context)
                .load(bahasaprogrammer.poster)
                .into(imgPoster)

            
        }
    }
}